modded class DayZPlayerImplementFallDamage
{
	const float		FD_DMG_FROM_HEIGHT		= TweakBLCfg.FD_DMG_FROM_HEIGHT;			//!< damage will not be taken into account bellow this HeightToDamage
	const float		FD_MAX_DMG_AT_HEIGHT	= TweakBLCfg.FD_MAX_DMG_AT_HEIGHT;			//!< height where player gets 100% damage
	const float		FD_MAX_BREAK_LEG_HEIGHT = TweakBLCfg.FD_MAX_BREAK_LEG_HEIGHT;			//!< height where legs break most of the time
	
}