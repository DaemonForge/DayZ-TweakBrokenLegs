modded class PainKillersMdfr: ModifierBase {
	const int LIFETIME = TweakBLCfg.PainKillersMdfr_LIFETIME;
}